import numpy as np
import matplotlib.pyplot as plt

# Função para criar uma matriz representando uma letra


def create_letter(letter):
    letters = {
        'I': np.array([
            [1, 1, 1],
            [0, 1, 0],
            [0, 1, 0],
            [0, 1, 0],
            [1, 1, 1]
        ]),
        'G': np.array([
            [0, 1, 1, 1, 0],
            [1, 0, 0, 0, 1],
            [1, 0, 0, 0, 0],
            [1, 0, 1, 1, 0],
            [0, 1, 0, 0, 1],
            [0, 0, 1, 1, 0]
        ]),
        'O': np.array([
            [0, 1, 1, 1, 0],
            [1, 0, 0, 0, 1],
            [1, 0, 0, 0, 1],
            [1, 0, 0, 0, 1],
            [0, 1, 1, 1, 0]
        ]),
        'R': np.array([
            [1, 1, 1, 0],
            [1, 0, 1, 0],
            [1, 1, 1, 0],
            [1, 0, 0, 1],
            [1, 0, 0, 1]
        ])
    }

    # Retorna uma matriz vazia se a letra não estiver definida
    return letters.get(letter, np.zeros((5, 3)))

# Função para criar a imagem do nome "Igor"


def create_name_image(name):
    name_matrix = [create_letter(letter) for letter in name]
    image = np.concatenate(name_matrix, axis=1)
    return image


# Nome a ser gerado
name = "IGOR"

# Criar imagem
name_image = create_name_image(name)

# Exibir a imagem
plt.imshow(name_image, cmap='gray', interpolation='nearest')
plt.axis('off')
plt.show()
